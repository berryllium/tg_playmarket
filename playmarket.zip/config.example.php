<?php
error_reporting(E_ALL);

define('TOKEN', '14123165:A42356nzK4-ShM9546fify-xt546remEE'); // токен бота
define('BOT_ID', 'fredsf_bace_bot'); // id бота
define('USER_ID', ['1257447230']); // id чатов telegram - перечисляем через запятую в массиве
define('MESSAGE', 'Привет!'); // сообщение для массовой рассылки